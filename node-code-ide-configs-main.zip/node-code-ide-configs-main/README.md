# node-code-ide-configs

Here are some IDE specific configs you can use while developing on [Node.js core](https://github.com/nodejs/node)

- Visual Studio Code, see [./vscode.md](./vscode.md)
- IntelliJ IDEs, see [IntelliJ-IDE.md](./IntelliJ-IDE.md)